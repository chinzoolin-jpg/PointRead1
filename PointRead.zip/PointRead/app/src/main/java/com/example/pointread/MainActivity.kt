package com.example.pointread

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var text: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)

        val input = findViewById<EditText>(R.id.inputText)
        text = findViewById(R.id.displayText)
        val button = findViewById<Button>(R.id.showButton)

        button.setOnClickListener {
            text.text = input.text.toString()
        }

        text.setOnClickListener {
            speak(text.text.toString())
        }
    }

    override fun onInit(status: Int) {}

    private fun speak(word: String) {
        val locale = if (word.any { it.code > 127 })
            Locale.TAIWAN
        else
            Locale.US

        tts.language = locale
        tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, "pointread")
    }
}